package at.gwt.ccc.exam.beans;

public class Pixeldata {

	private int rows;
	private int cols;

	private int[][] data;

	public Pixeldata(int rows, int cols) {
		this.rows = rows;
		this.cols = cols;

		this.data = new int[rows][cols];
	}

	public void setIntensity(int row, int col, int intensity) {
		this.data[row][col] = intensity;
	}

	/**
	 * @return true if all pixels do have the intensity of 0. This method does fail fast on the first occurrence of a non-zero value.
	 */
	public boolean isEmpty() {
		boolean empty = true;

		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				empty = this.data[i][j] == 0;

				if (!empty) {
					return empty;
				}
			}
		}

		return empty;
	}

	public int getRows() {
		return rows;
	}

	public int getCols() {
		return cols;
	}
}
