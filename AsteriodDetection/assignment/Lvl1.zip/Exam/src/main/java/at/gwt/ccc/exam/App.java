package at.gwt.ccc.exam;

import at.gwt.ccc.exam.beans.Observation;
import at.gwt.ccc.exam.util.InputParser;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collection;
import java.util.function.Consumer;

public class App {
	private static final Logger logger = LogManager.getLogger();

	private static final Path RESOURCES = Paths.get("src/main/resources");

	public static void main(String[] args) {
		logger.info("Starting application");

		doLevel1();

		logger.info("Handled all levels");
	}

	private static void doLevel1() {
		logger.info("Solving level 1");

		try {
			Files.list(RESOURCES.resolve("level1/input"))
					.forEach(App::solveLevel1File);
		} catch (IOException e) {
			logger.error(e);
		}

		logger.info("Finished level 1");
	}

	private static void solveLevel1File(Path inputFile) {
		try {
			Observation missionData = InputParser.parseMissionData(inputFile);
			Collection<Integer> asteroidTimestamps = new Analyst().getAsteroidTimestamps(missionData);

			// write result to file
			String outFileName = inputFile.toFile().getName().replace(".inp", ".outp");
			Path outputPath = RESOURCES.resolve("level1/output").resolve(outFileName);

			writeSolution(outputPath, w ->
					asteroidTimestamps.forEach(t -> {
						try {
							w.write(t.toString());
							w.newLine();
						} catch (IOException e) {
							logger.error(e);
						}

					})
			);

		} catch (IOException e) {
			logger.error("Cannot handle file {}", inputFile.toString(), e);
		}
	}

	private static void writeSolution(Path outputPath, Consumer<BufferedWriter> contentWriter) throws IOException {
		try (BufferedWriter w = Files.newBufferedWriter(outputPath)) {
			contentWriter.accept(w);
		}
	}
}
