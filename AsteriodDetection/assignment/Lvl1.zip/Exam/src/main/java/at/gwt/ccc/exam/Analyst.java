package at.gwt.ccc.exam;

import at.gwt.ccc.exam.beans.Image;
import at.gwt.ccc.exam.beans.Observation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.stream.Collectors;

public class Analyst {

	public Collection<Integer> getAsteroidTimestamps(Observation missionData) {
		return missionData.getImages().stream()
				.filter(i -> !i.getPixeldata().isEmpty())
				.map(Image::getTimestamp)
				.sorted()
				.collect(Collectors.toList());
	}

}
